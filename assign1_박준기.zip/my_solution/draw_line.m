d = 0:pi/180:2*pi;
l1 = 10 * cos(d) + 10 * sin(d);
plot(d/pi, l1)
grid on
hold on

l2 = 20 * cos(d) + 20 * sin(d);
plot(d/pi, l2)

l3 = 30 * cos(d) + 30 * sin(d);
plot(d/pi, l3)

xlabel('theta(PI)')
ylabel('rho')
legend('P1(10,10)' , 'P2(20,20)', 'P3(30,30)')

hold off